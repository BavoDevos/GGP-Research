#pragma once
#include "stdafx.h"
#define and &&
#define or ||

using namespace Elite;

namespace Utils
{
	inline Elite::Polygon CreateSquare(Vector2 bottomleft, float width, float height)
	{
		std::vector<Vector2> Vertices;
		Vertices.push_back(Vector2(bottomleft));
		Vertices.push_back(Vector2(bottomleft.x, bottomleft.y + height));
		Vertices.push_back(Vector2(bottomleft.x + width, bottomleft.y + height));
		Vertices.push_back(Vector2(bottomleft.x + width, bottomleft.y));

		return Elite::Polygon(Vertices);
	}

	struct WorldBox
	{
		Vector2 leftBottom, leftTop, rightTop, rightBottom;
		std::vector<Vector2> points;

		WorldBox(Vector2 leftBottom, float width, float height) : leftBottom{ leftBottom }, leftTop{ leftBottom.x,leftBottom.y + height },
			rightTop{ leftBottom.x + width,leftBottom.y + height }, rightBottom{ leftBottom.x + width,leftBottom.y }
		{
			points.push_back(leftBottom);
			points.push_back(leftTop);
			points.push_back(rightTop);
			points.push_back(rightBottom);
		};

		const Vector2 getLeftBottom() { return leftBottom; };
		const Vector2 getleftTop() { return leftTop; };
		const Vector2 getrightTop() { return rightTop; };
		const Vector2 getrightBottom() { return rightBottom; };

		const std::vector<Vector2> GetPointsContainer() { return points; };

	};

	inline bool isPointOverLine(Vector2 point,Vector2 lineCorner,bool upwardsIsOut,bool rightIsOut)
	{
		bool y=false;
		bool x = false;

		if (upwardsIsOut)
		{
			if (point.y > lineCorner.y)
			{
				y = true;
			}
		}
		else
		{
			if (point.y < lineCorner.y)
			{
				y = true;
			}
		}

		if (rightIsOut)
		{
			if (point.x > lineCorner.x)
			{
				x = true;
			}
		}
		else
		{
			if (point.x< lineCorner.x)
			{
				x = true;
			}
		}


		return x or y;
		
	}
}


enum class SnakeDirection
{
	up, left, down, right
};