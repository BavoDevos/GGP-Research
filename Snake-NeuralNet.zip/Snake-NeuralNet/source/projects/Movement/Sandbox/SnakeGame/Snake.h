#pragma once

#include "..\Utils.h"
#include <map>


class Snake
{
public:
	//constructor etc
	Snake(const Vector2 BottomLeft);
	~Snake();
public:
	//functions
	void update();
	void render();
	void eatingFood();
	void SetSnakeDirection(SnakeDirection direction);
	bool BodyCollisionCheck();
	const int remainingMoves();


private:
	//variables
	SnakeDirection m_Direction;
	Vector2 m_SnakeHeadBottomLeft;
	Elite::Polygon* m_SnakeHead;
	std::list<Vector2> m_SnakePath;
	int RemainingMoves;
	//std::map<Vector2*, Elite::Polygon> renderPolygons;
	int m_SnakeSize;

	void SetPath();
	

public:
	//getters and setters
	const Vector2 GetHeadLocation();
	const int returnDirection();
	const std::list<Vector2> getSnakeBody();
	const int returnSize();
};

