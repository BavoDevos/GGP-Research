#pragma once
#include "..\utils.h"
class Food
{
public:

	Food(Elite::Vector2 BottomLeftOfWorld);
	~Food();

	void render();
	const Vector2 GetLocation();
	void RespawnSelf();
	void SetLocation(Vector2 bottomleft);

private:
	Elite::Vector2 BottomLeftOfWorld;
	Elite::Vector2 bottomLeftOfSelf;
	Elite::Polygon* RenderPolygon;
};

