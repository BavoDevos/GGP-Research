#include "stdafx.h"
#include "SnakeGame.h"
#include "Food.h"
#include "NeuralNetwork/NeuralNetwork.h"
#define and &&
#define or ||

SnakeGame::SnakeGame(Elite::Vector2 bottomLeft)
	:GameBox{bottomLeft,150,150},SnakeAlive{true}
{
	m_bottomLeft = bottomLeft;
	m_Snake =new Snake(Vector2(bottomLeft.x+(7*10), bottomLeft.y+(3*10)));
	GameBoxRenderPolygon = Elite::Polygon((GameBox.GetPointsContainer()));
	count = 0;
	//m_Food = new Food(bottomLeft);
	m_Brain = new NeuralNetwork(9, 40, 4);
	Generation = 0;
}
SnakeGame::~SnakeGame()
{
	delete m_Snake;
	//delete m_Food;
	delete m_Brain;
}

void SnakeGame::update()
{
	if (SnakeAlive)
	{
		if (m_Snake->BodyCollisionCheck())
		{
			SnakeAlive = false;
			m_SnakeFitness -= 500;
			return;
		}
		
		/*if (m_Snake->remainingMoves() < 0)
		{
			SnakeAlive = false;
			m_SnakeFitness -= 50;
			return;
		}*/

		m_Snake->update();
	
		m_SnakeFitness += 30;

		if (
			Utils::isPointOverLine(m_Snake->GetHeadLocation(), GameBox.getLeftBottom(), false, false)
			or
			Utils::isPointOverLine(m_Snake->GetHeadLocation(), GameBox.getrightTop(), true, true)
			)
		{
			SnakeAlive = false;
			m_SnakeFitness -= 500;
		}

		//if (m_Snake->GetHeadLocation() == m_Food->GetLocation())
		//{
		//	//std::cout << "EAT";
		//	m_Snake->eatingFood();
		//	//m_Food->RespawnSelf();

		//	//m_SnakeFitness += 50;
		//	
		//}
	}

	

}


void SnakeGame::render()
{
	if (SnakeAlive)
	{
		//DEBUGRENDERER2D->DrawSolidCircle(Vector2(150, 150), 1, Vector2(0, 0), Elite::Color(1, 0, 0));
		DEBUGRENDERER2D->DrawPolygon(&GameBoxRenderPolygon, Elite::Color(1, 0, 0));
		m_Snake->render();
		//m_Food->render();
	}
	else
	{
		//std::cout << "i render death\n";
		DEBUGRENDERER2D->DrawSolidPolygon(&GameBoxRenderPolygon, Elite::Color(1, 0, 0),0);
	}

}

void SnakeGame::resetGame()
{
	delete m_Snake;
	m_Snake = new Snake(m_bottomLeft);
	//m_Food->RespawnSelf();
	SnakeAlive = true;
	m_SnakeFitness = 0;

}

void SnakeGame::ActiveBrain()
{

	m_Brain->giveInputs(getInputs());
	m_Snake->SetSnakeDirection(m_Brain->GetOutput());

}

void SnakeGame::HumanInputHandler()
{
	if (INPUTMANAGER->IsKeyboardKeyDown(eScancode_Up))
	{
		m_Snake->SetSnakeDirection(SnakeDirection::up);
	}
	if (INPUTMANAGER->IsKeyboardKeyDown(eScancode_Left))
	{
		m_Snake->SetSnakeDirection(SnakeDirection::left);
	}
	if (INPUTMANAGER->IsKeyboardKeyDown(eScancode_Right))
	{
		m_Snake->SetSnakeDirection(SnakeDirection::right);
	}
	if (INPUTMANAGER->IsKeyboardKeyDown(eScancode_Down))
	{
		m_Snake->SetSnakeDirection(SnakeDirection::down);
	}

}

bool SnakeGame::IsSnakeAlive()
{
	return SnakeAlive;
}

int SnakeGame::getSnakeFitness()
{
	Generation++;
	return m_SnakeFitness;
}

std::vector<float> SnakeGame::getInputs()
{
	std::vector<float> toReturn;

	//toReturn.push_back
	//(
	//	float(m_Food->GetLocation().x- m_Snake->GetHeadLocation().x)/10
	//);

	//toReturn.push_back
	//(
	//	float(m_Food->GetLocation().y- m_Snake->GetHeadLocation().y)/10
	//);

	/*toReturn.push_back
	(
		float(m_Snake->GetHeadLocation().x-m_Food->GetLocation().x) / 10
	);

	toReturn.push_back
	(
		float( m_Snake->GetHeadLocation().y-m_Food->GetLocation().y) / 10
	);*/

	toReturn.push_back
	(
		DistanceToWall(true, false)/10
	);

	toReturn.push_back
	(
		DistanceToWall(false, false)/10
	);

	toReturn.push_back
	(
		DistanceToWall(true, false)/10
	);

	toReturn.push_back
	(
		DistanceToWall(true, true)/10
	);
	if (m_Snake->returnSize() < 2)
	{
		toReturn.push_back
		(
			DistanceToOwnBody(false, true,false)/10
		);

		toReturn.push_back
		(
			DistanceToOwnBody(true, true,false)/10
		);

		toReturn.push_back
		(
			DistanceToOwnBody(true, false,false)/10
		);

		toReturn.push_back
		(
			DistanceToOwnBody(false, false,false)/10
		);
	}
	else
	{
		toReturn.push_back
		(
			DistanceToOwnBody(true, true, true)/10
		);

		toReturn.push_back
		(
			DistanceToOwnBody(false, true, true)/10
		);

		toReturn.push_back
		(
			DistanceToOwnBody(true, false, true)/10
		);

		toReturn.push_back
		(
			DistanceToOwnBody(false, false, true)/10
		);
	}

	toReturn.push_back
	(
		m_Snake->returnDirection()
	);
	//std::vector<float> toReturn;

	//toReturn.push_back
	//(
	//	rand() % 100
	//);

	//toReturn.push_back
	//(
	//	rand() % 100
	//);

	//toReturn.push_back
	//(
	//	rand() % 100
	//);

	//toReturn.push_back
	//(
	//	rand() % 100
	//);

	//toReturn.push_back
	//(
	//	rand() % 100
	//);

	//toReturn.push_back
	//(
	//	rand() % 100
	//);
	//if (true)
	//{
	//	toReturn.push_back
	//	(
	//		rand() % 100
	//	);

	//	toReturn.push_back
	//	(
	//		rand() % 100
	//	);

	//	toReturn.push_back
	//	(
	//		rand() % 100
	//	);

	//	toReturn.push_back
	//	(
	//		rand() % 100
	//	);
	//}

	//toReturn.push_back
	//(
	//	m_Snake->returnDirection()
	//);

	std::cout << '\n';
	return toReturn;

}


float SnakeGame::DistanceToWall(bool positive, bool x)
{

	if (x)
	{
		if (positive)
		{
			return 	(m_bottomLeft.x + 150) - m_Snake->GetHeadLocation().x;
		}
		else
		{
			return  m_Snake->GetHeadLocation().x - m_bottomLeft.x;
		}
	
	}
	else
	{
		if (positive)
		{
			return (m_bottomLeft.y + 150) - m_Snake->GetHeadLocation().y;
		}
		else
		{
			return  m_Snake->GetHeadLocation().y - m_bottomLeft.y;
		}
	}
}


float SnakeGame::DistanceToOwnBody(bool positive, bool x,bool snakeIsBigEnough)
{
	float closestDistance = 160;
	if (!snakeIsBigEnough)
	{
		return 160;
	}
	int i{0};
	if (positive)
	{
		if (x)
		{
			for (Vector2 bodypart : m_Snake->getSnakeBody())
			{
				if (i == m_Snake->getSnakeBody().size() - 1)continue;

				bodypart.x += 5;
				bodypart.y += 5;

				if (m_Snake->GetHeadLocation().y == bodypart.y)
				{
					float checking = bodypart.x - m_Snake->GetHeadLocation().x;

					if (checking < closestDistance)
					{
						closestDistance = checking;
					}
				}
			}

		}
		else
		{
			for (Vector2 bodypart : m_Snake->getSnakeBody())
			{
				if (i == m_Snake->getSnakeBody().size() - 1)continue;

				bodypart.x += 5;
				bodypart.y += 5;

				if (m_Snake->GetHeadLocation().x == bodypart.x)
				{
					float checking = bodypart.y - m_Snake->GetHeadLocation().y;

					if (checking < closestDistance)
					{
						closestDistance = checking;
					}
				}
			}
		}

	}
	else
	{
		if (x)
		{
			for (Vector2 bodypart : m_Snake->getSnakeBody())
			{
				if (i == m_Snake->getSnakeBody().size() - 1)continue;

				bodypart.x += 5;
				bodypart.y += 5;

				if (m_Snake->GetHeadLocation().y == bodypart.y)
				{
					float checking = m_Snake->GetHeadLocation().x - bodypart.x;

					if (checking < closestDistance)
					{
						closestDistance = checking;
					}
				}
			}
		}
		else
		{
			for (Vector2 bodypart : m_Snake->getSnakeBody())
			{
				if (i == m_Snake->getSnakeBody().size() - 1)continue;

				bodypart.x += 5;
				bodypart.y += 5;

				if (m_Snake->GetHeadLocation().x == bodypart.x)
				{
					float checking = m_Snake->GetHeadLocation().y - bodypart.y;

					if (checking < closestDistance)
					{
						closestDistance = checking;
					}
				}
			}
		}
	}
	return closestDistance;
}

void SnakeGame::SetWeightsAndBiases(std::vector<std::vector<std::vector<float>>> weights, std::vector<std::vector<float>> biases)
{
	m_Brain->SetWeightsAndBiases(weights, biases);
}
const std::vector<std::vector<std::vector<float>>> SnakeGame::getWeights()
{
	return m_Brain->getWeights();
}
const std::vector<std::vector<float>> SnakeGame::getBiases()
{
	return m_Brain->getBiases();
}

void SnakeGame::mutateBrain(bool weights,bool biases,bool agressive)
{
	if(!agressive)
	{
		m_Brain->Mutate(weights, biases);
	}
	else
	{
		m_Brain->AgressiveMutate(weights, biases);
	}
}