#pragma once
#include "..\Utils.h"
#include "Snake.h"
#include "food.h"
class NeuralNetwork;
static int Generation;
class SnakeGame
{
public:
	SnakeGame(Elite::Vector2 bottomLeft);
	~SnakeGame();

	void update();
	void render();
	void HumanInputHandler();
	bool IsSnakeAlive();
	void resetGame();
	int getSnakeFitness();
	void ActiveBrain();
	void mutateBrain(bool weights, bool biases, bool agressive = false);

	void SetWeightsAndBiases(std::vector<std::vector<std::vector<float>>> weights, std::vector<std::vector<float>> biases);
	const std::vector<std::vector<std::vector<float>>> getWeights();
	const std::vector<std::vector<float>> getBiases();

	NeuralNetwork* m_Brain;
private:
	Utils::WorldBox GameBox;
	Snake* m_Snake;
	Food* m_Food;
	Vector2 m_bottomLeft;
	Elite::Polygon GameBoxRenderPolygon;
	bool SnakeAlive;
	int count;
	int m_SnakeFitness{0};

	//private functions 
	std::vector<float> getInputs();
	float DistanceToWall(bool upwards, bool right);
	float DistanceToOwnBody(bool upwards, bool right,bool snakeIsBigEnough);

};

