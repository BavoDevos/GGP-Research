#include "stdafx.h"
#include "Snake.h"


//constructor etc
Snake::Snake(const Vector2 BottomLeft)
	:m_SnakeHeadBottomLeft{BottomLeft},m_Direction{SnakeDirection::right},m_SnakeSize{2}
{
	m_SnakeHead = nullptr;
	m_SnakePath.resize(static_cast<size_t>(10));
	RemainingMoves = 80;
}
Snake::~Snake()
{

}

//functions
void Snake::update()
{

	SetPath();

	switch (m_Direction)
	{
	case SnakeDirection::up:
		m_SnakeHeadBottomLeft.y += 10;
		break;
	case SnakeDirection::left:
		m_SnakeHeadBottomLeft.x -= 10;
		break;
	case SnakeDirection::down:
		m_SnakeHeadBottomLeft.y -= 10;
		break;
	case SnakeDirection::right:
		m_SnakeHeadBottomLeft.x += 10;
		break;
	default:
		break;
	}
	
	RemainingMoves -= 1;
}
void Snake::render()
{
	m_SnakeHead = new Elite::Polygon(Utils::CreateSquare(m_SnakeHeadBottomLeft, 10, 10));
	DEBUGRENDERER2D->DrawSolidPolygon(m_SnakeHead, Elite::Color(0, 1, 0),0);
	delete m_SnakeHead;

	if (m_SnakeSize != 1)
	{
		for (int i = 0; i < m_SnakeSize - 1; ++i)
		{
			auto iterator = std::next(m_SnakePath.begin(), i);
			//auto search = renderPolygons.find(&*iterator);

			//if ( search != renderPolygons.end())
			//{
			//	DEBUGRENDERER2D->DrawSolidPolygon(&renderPolygons[&*iterator], Elite::Color(0, 1, 1), 0);
			//}
			//else
			//{
			//	Elite::Polygon* TempPolygon = new Elite::Polygon(Utils::CreateSquare(*iterator, 10, 10));
			//	DEBUGRENDERER2D->DrawSolidPolygon(TempPolygon, Elite::Color(0, 1, 1), 0);
			//	renderPolygons[&*iterator] = *TempPolygon;
			//	//delete TempPolygon;
			//}
			Elite::Polygon* TempPolygon = new Elite::Polygon(Utils::CreateSquare(*iterator, 10, 10));
			DEBUGRENDERER2D->DrawPolygon(TempPolygon, Elite::Color(0, 1, 1),0);
			delete TempPolygon;
			
			
		}
	}
}

void Snake::eatingFood()
{
	m_SnakeSize++;
	m_SnakePath.resize(m_SnakeSize);
	//std::cout << "food\n";
	RemainingMoves += 30;
}

void Snake::SetPath()
{
	if (m_SnakeSize == 1)
	{
		m_SnakePath.clear();
		m_SnakePath.push_back(m_SnakeHeadBottomLeft);
	}
	else
	{
		m_SnakePath.push_front(m_SnakeHeadBottomLeft);
		
		if (m_SnakePath.size() > m_SnakeSize + 1)
		{
			m_SnakePath.pop_back();
		}
	}
}

bool Snake::BodyCollisionCheck()
{

	for (int i = 1; i < m_SnakeSize - 1; ++i)
	{
		auto iterator = std::next(m_SnakePath.begin(), i);

		if (*iterator == m_SnakeHeadBottomLeft)
		{
			return true;
			
		}
	}
	return false;
}

//getters and setters
const Vector2 Snake::GetHeadLocation()
{
	return Vector2(m_SnakeHeadBottomLeft.x + 5, m_SnakeHeadBottomLeft.y + 5);
}
const int Snake::remainingMoves()
{
	return RemainingMoves;
}


void Snake::SetSnakeDirection(SnakeDirection direction)
{
	switch (direction)
	{
	case SnakeDirection::up:
		if (m_Direction == SnakeDirection::down)
			return;
		m_Direction = direction;
		break;
	case SnakeDirection::left:
		if (m_Direction == SnakeDirection::right)
			return;
		m_Direction = direction;
		break;
	case SnakeDirection::down:
		if (m_Direction == SnakeDirection::up)
			return;
		m_Direction = direction;
		break;
	case SnakeDirection::right:
		if (m_Direction == SnakeDirection::left)
			return;
		m_Direction = direction;
		break;
	default:
		break;
	}


}

const int Snake::returnDirection()
{
	switch (m_Direction)
	{
	case SnakeDirection::up:
		return 1;
		break;
	case SnakeDirection::left:
		return 4;
		break;
	case SnakeDirection::down:
		return 3;
		break;
	case SnakeDirection::right:
		return 2;
		break;
	}
}

const std::list<Vector2> Snake::getSnakeBody()
{
	return m_SnakePath;
}

const int Snake::returnSize()
{
	return m_SnakeSize;
}