#include "stdafx.h"
#include "Neuron.h"
#include <cmath>

Neuron::Neuron(int AmountOfoutputs, int amountOfInputs)
{
	m_Inputs.resize(amountOfInputs);
	m_Outputs.resize(AmountOfoutputs);
	m_Weights.resize(AmountOfoutputs);
	for (int i = 0; i < AmountOfoutputs; ++i)
	{
		m_Weights[i] = (rand() % 1000) / 1000.0f;
	}
}
Neuron::~Neuron()
{

}
void Neuron::setInput(const float input)
{
	m_Inputs[m_InputsReceived] = input;
	m_InputsReceived++;
	m_HasNeuronFired = false;
}
float Neuron::getOutput(int indexOfOutput)
{
	m_InputsReceived = 0;
	if (!m_HasNeuronFired)
	{
		fireNeuron(indexOfOutput);
		m_HasNeuronFired = true;
	}

	return m_Outputs[0]*m_Weights[indexOfOutput];
}

const float Neuron::getInput(int nextNeuronIndex)
{
	m_InputsReceived = 0;
	return m_Inputs[0]*m_Weights[nextNeuronIndex];
}
const float Neuron::getBias()
{
	return m_Bias;
}

void Neuron::fireNeuron(int index)
{
	float WeightedSum{ 0 };

	for (float data : m_Inputs)
	{
		WeightedSum += data;
	}

	m_OutputBeforeWeights = WeightedSum + m_Bias;

	m_Outputs[0] = m_OutputBeforeWeights/100;//= (1/(1+exp(m_OutputBeforeWeights)));

	m_InputsReceived = 0;

}
const std::vector<float> Neuron::getWeights()
{
	return m_Weights;
}

void Neuron::SetWeights(const std::vector<float> newWeights)
{
	m_Weights.clear();
	m_Weights = newWeights;
}

void Neuron::SetBias(const float newBias)
{
	m_Bias = newBias;
}

void Neuron::Mutate(bool weights,bool biases)
{
	if (weights)
	{
		for (float weights : m_Weights)
		{

			weights += (((rand() % 1000)-500)) / 1000.f;
			
		}
	}

	if (biases)
	{
		
		m_Bias += ((rand() % 1000)-500) / 100.f;
		
		
	}
}


void Neuron::AgressiveMutate(bool weights, bool biases)
{
	if (weights)
	{
		for (float weights : m_Weights)
		{
			
			weights += (((rand() % 2000)-1000)) / 100.f;
			
			
		}
	}

	if (biases)
	{

		m_Bias += ((rand() % 2000)-1000) / 100.f;

	}
}