#include "stdafx.h"
#include "NeuralNetwork.h"
#include "Neuron.h"

NeuralNetwork::NeuralNetwork(int inputlayersize, int hiddenlayersize, int outputsize)
{
	m_InputLayer.resize(inputlayersize);
	m_HiddenLayer1.resize(hiddenlayersize);
	m_HiddenLayer2.resize(hiddenlayersize);
	m_OutputLayer.resize(outputsize);

	for (int i = 0; i < m_InputLayer.size(); i++)
	{
		m_InputLayer[i] = new Neuron(hiddenlayersize, 1);
	}

	for (int i = 0; i < m_HiddenLayer1.size(); i++)
	{
		m_HiddenLayer1[i] = new Neuron(hiddenlayersize,inputlayersize);
	}
	for (int i = 0; i < m_HiddenLayer2.size(); i++)
	{
		m_HiddenLayer2[i] = new Neuron(outputsize, hiddenlayersize);
	}

	for (int i = 0; i < m_OutputLayer.size(); i++)
	{
		m_OutputLayer[i] = new Neuron(1,hiddenlayersize);
	}

}

NeuralNetwork::~NeuralNetwork()
{
	for (Neuron* neurons : m_InputLayer)
	{
		delete neurons;
	}
	for (Neuron* neurons : m_HiddenLayer1)
	{
		delete neurons;
	}
	for (Neuron* neurons : m_HiddenLayer2)
	{
		delete neurons;
	}
	for (Neuron* neurons : m_OutputLayer)
	{
		delete neurons;
	}
}

SnakeDirection NeuralNetwork::GetOutput()
{

	processData();

	float highest = outputUp;

	if (highest < outputRight)
	{
		highest = outputRight;
	}

	if (highest < outputDown)
	{
		highest =outputDown;
	}

	if (highest <OutputLeft)
	{
		highest =OutputLeft;
	}
	//std::cout << "up " << outputUp << '\n' << "right " << outputRight << '\n' << "down " << outputDown << '\n'
	//	<< "left " << OutputLeft << '\n';

	//we now have the highest

	if (highest == outputUp)
	{
		return SnakeDirection::up;
	}

	if (highest == outputRight)
	{
		return SnakeDirection::right;
	}

	if (highest == outputDown)
	{
		return SnakeDirection::down;
	}

	if (highest == OutputLeft)
	{
		return SnakeDirection::left;
	}
}

void NeuralNetwork::processData()
{
	int i{ 0 };
	for (Neuron* HiddenNeuron : m_HiddenLayer1)
	{
		for (Neuron* InputNeuron : m_InputLayer)
		{
			HiddenNeuron->setInput(InputNeuron->getInput(i));
		}
		i++;
	}
	i = 0;
	for (Neuron* hidden : m_HiddenLayer2)
	{

		for (Neuron* InputNeuron : m_HiddenLayer1)
		{
			hidden->setInput(InputNeuron->getOutput(i));

		}
		i++;
	}
	i=0;
	for (Neuron* output : m_OutputLayer)
	{

		for (Neuron* InputNeuron : m_HiddenLayer2)
		{
			output->setInput(InputNeuron->getOutput(i));
			
		}
		i++;
	}

	i = 0;
	for (Neuron* output : m_OutputLayer)
	{
		switch (i)
		{
		case 0:
			outputUp = output->getOutput(0);
			break;
		case 1:
			outputRight = output->getOutput(0);
			break;
		case 2:
			outputDown = output->getOutput(0);
			break;
		case 3:
			OutputLeft = output->getOutput(0);
			break;
		default:
			break;
		}

		i++;
	}
}

const void NeuralNetwork::giveInputs(const std::vector<float> inputs)
{
	for (int i = 0; i < inputs.size(); i++)
	{
		m_InputLayer[i]->setInput(inputs[i]);
	}
}

void NeuralNetwork::SetWeightsAndBiases(const std::vector<std::vector<std::vector<float>>> weights,const std::vector<std::vector<float>> biases)
{
	int vectorI{0};

	std::vector<std::vector<float>> inputLayerVector = weights[0];
	std::vector<std::vector<float>> hiddenLayerVector1 = weights[1];
	std::vector<std::vector<float>> hiddenLayerVector2 = weights[2];
	std::vector<std::vector<float>> outputLayerVector = weights[3];
	int i = 0;
	for (std::vector<float> weights : inputLayerVector)
	{
		m_InputLayer[i]->SetWeights(weights);
		i++;
	}
	i = 0;
	for (std::vector<float> weights : hiddenLayerVector1)
	{
		m_HiddenLayer1[i]->SetWeights(weights);
		i++;
	}

	i = 0;
	for (std::vector<float> weights : hiddenLayerVector2)
	{
		m_HiddenLayer2[i]->SetWeights(weights);
		i++;
	}

	i = 0;
	for (std::vector<float> weights : outputLayerVector)
	{
		m_OutputLayer[i]->SetWeights(weights);
		i++;
	}


	vectorI = 0;

	for (const auto& vectors : biases)
	{
		int neuronsI{ 0 };
		for (const auto& bias : vectors)
		{
			switch (vectorI)
			{
			case 0:
				m_InputLayer[neuronsI]->SetBias(bias);
				break;
			case 1:
				m_HiddenLayer1[neuronsI]->SetBias(bias);
				break;
			case 2:
				m_HiddenLayer2[neuronsI]->SetBias(bias);
				break;
			case 3:
				m_OutputLayer[neuronsI]->SetBias(bias);
				break;
			};
			neuronsI++;
		}
		vectorI++;
	}
}

const std::vector<std::vector<std::vector<float>>> NeuralNetwork::getWeights()
{
	std::vector<std::vector<std::vector<float>>> toReturn;
	int neurons = 0;
	
	std::vector<std::vector<float>> inputlayer;
	std::vector<std::vector<float>> hiddenlayer1;
	std::vector<std::vector<float>> hiddenlayer2;
	std::vector<std::vector<float>> outputlayer;
	inputlayer.resize(m_InputLayer.size());
	int i{ 0 };
	for (Neuron* neuron : m_InputLayer)
	{
		inputlayer[i] = neuron->getWeights();
		i++;
	}
	i = 0;
	hiddenlayer1.resize(m_HiddenLayer1.size());
	for (Neuron* neuron : m_HiddenLayer1)
	{
		hiddenlayer1[i] = neuron->getWeights();
		i++;
	}
	i = 0;
	hiddenlayer2.resize(m_HiddenLayer2.size());
	for (Neuron* neuron : m_HiddenLayer2)
	{
		hiddenlayer2[i] = neuron->getWeights();
		i++;
	}
	i = 0;
	outputlayer.resize(m_OutputLayer.size());
	for (Neuron* neuron : m_OutputLayer)
	{
		outputlayer[i] = neuron->getWeights();
		i++;
	}
	toReturn.resize(4);
	toReturn[0] = inputlayer;
	toReturn[1] = hiddenlayer1;
	toReturn[2] = hiddenlayer1;
	toReturn[3] = outputlayer;

	return toReturn;

}
const std::vector<std::vector<float>> NeuralNetwork::getBiases()
{
	std::vector<std::vector<float>> toReturn;
	int i = 0;
	toReturn.resize(4);
	toReturn[0].resize(m_InputLayer.size());
	for (Neuron* InputNeuron : m_InputLayer)
	{
		toReturn[0][i] = m_InputLayer[i]->getBias();
		i++;
	}
	i = 0;
	toReturn[1].resize(m_HiddenLayer1.size());
	for (Neuron* hiddenNeuron : m_HiddenLayer1)
	{
		toReturn[1][i] = m_HiddenLayer1[i]->getBias();
		i++;
	}
	i = 0;
	toReturn[2].resize(m_HiddenLayer2.size());
	for (Neuron* hiddenNeuron : m_HiddenLayer2)
	{
		toReturn[2][i] = m_HiddenLayer2[i]->getBias();
		i++;
	}
	i = 0;
	toReturn[3].resize(m_OutputLayer.size());
	for (Neuron* outputNeuron : m_OutputLayer)
	{
		
		toReturn[3][i] = m_OutputLayer[i]->getBias();
		i++;
	}

	return toReturn;
}

void NeuralNetwork::Mutate(bool weights, bool biases)
{

	for (Neuron* neurons : m_InputLayer)
	{
		neurons->Mutate(weights, biases);
	}

	for (Neuron* neurons : m_HiddenLayer1)
	{
		neurons->Mutate(weights, biases);
	}

	for (Neuron* neurons : m_HiddenLayer2)
	{
		neurons->Mutate(weights, biases);
	}

	for (Neuron* neurons : m_OutputLayer)
	{
		neurons->Mutate(weights, biases);
	}
}
void NeuralNetwork::AgressiveMutate(bool weights, bool biases)
{

	for (Neuron* neurons : m_InputLayer)
	{
		neurons->AgressiveMutate(weights, biases);
	}

	for (Neuron* neurons : m_HiddenLayer1)
	{
		neurons->AgressiveMutate(weights, biases);
	}
	for (Neuron* neurons : m_HiddenLayer2)
	{
		neurons->AgressiveMutate(weights, biases);
	}

	for (Neuron* neurons : m_OutputLayer)
	{
		neurons->AgressiveMutate(weights, biases);
	}
}
