#pragma once
class Neuron
{
public:
	Neuron(int AmountOfoutputs,int amountOfInputs);
	~Neuron();
	void setInput(const float input);
	const float getInput(int nextNeuronIndex);
	float getOutput(int indexOfOutput);
	const float getBias();
	void fireNeuron(int index);
	const std::vector<float> getWeights();
	void SetWeights(const std::vector<float> newWeights);
	void SetBias(const float newBias);
	void Mutate(bool weights, bool biases);
	void AgressiveMutate(bool weights, bool biases);
private:
	std::vector<float> m_Weights;
	std::vector<float> m_Inputs;
	std::vector<float> m_Outputs;
	int m_InputsReceived{0};
	bool m_HasNeuronFired{ false };
	float m_OutputBeforeWeights{0};
	float m_Bias{0};
};

