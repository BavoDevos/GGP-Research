#pragma once
#include "../../Utils.h"
class Neuron;


class NeuralNetwork
{
public :

	NeuralNetwork(int inputlayersize,int hiddenlayersize,int outputsize);
	~NeuralNetwork();
	const void giveInputs(const std::vector<float> inputs);
	SnakeDirection GetOutput();
	void SetWeightsAndBiases(std::vector<std::vector<std::vector<float>>> weights,std::vector<std::vector<float>> biases);
	const std::vector<std::vector<std::vector<float>>> getWeights();
	const std::vector<std::vector<float>> getBiases();

	void Mutate(bool weights, bool biases);
	void AgressiveMutate(bool weights, bool biases);

private :
	std::vector<Neuron*> m_InputLayer;
	std::vector<Neuron*> m_HiddenLayer1;
	std::vector<Neuron*> m_HiddenLayer2;
	std::vector<Neuron*> m_OutputLayer;
	float outputUp;
	float outputRight;
	float outputDown;
	float OutputLeft;
	void processData();

};

