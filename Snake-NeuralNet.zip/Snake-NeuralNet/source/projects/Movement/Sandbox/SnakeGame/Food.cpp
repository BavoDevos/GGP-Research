#include "stdafx.h"
#include "Food.h"


Food::Food(Elite::Vector2 BottomLeftOfWorld)
	:BottomLeftOfWorld{BottomLeftOfWorld}
{
	float randX = ((rand() % 15) * 10);
	float randY = ((rand() % 15) * 10);

	RespawnSelf();
	//RenderPolygon = Utils::CreateSquare(bottomLeftOfSelf, 10, 10);
}
Food::~Food()
{

}

void Food::SetLocation(Vector2 bottomleft)
{
	bottomLeftOfSelf = bottomleft;
}

void Food::render()
{
	DEBUGRENDERER2D->DrawSolidPolygon(RenderPolygon, Elite::Color(1, 0, 0), 0);	
}
const Vector2 Food::GetLocation()
{
	return Vector2(bottomLeftOfSelf.x + 5, bottomLeftOfSelf.y + 5);
}
void Food::RespawnSelf()
{
	delete RenderPolygon;

	float randX = ((rand() % 15) * 10);
	float randY = ((rand() % 15) * 10);

	bottomLeftOfSelf = Elite::Vector2(BottomLeftOfWorld.x + randX, BottomLeftOfWorld.y + randY);
	RenderPolygon =new Elite::Polygon( Utils::CreateSquare(bottomLeftOfSelf, 10, 10));
}