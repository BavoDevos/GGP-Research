#ifndef SANDBOX_APPLICATION_H
#define SANDBOX_APPLICATION_H
//-----------------------------------------------------------------
// Includes & Forward Declarations
//-----------------------------------------------------------------
#include "framework/EliteInterfaces/EIApp.h"

class Renderer;
class SnakeGame;

//-----------------------------------------------------------------
// Application
//-----------------------------------------------------------------
class App_Sandbox final : public IApp
{
public:
	//Constructor & Destructor
	App_Sandbox() = default;
	virtual ~App_Sandbox() final;

	//App Functions
	void Start() override;
	void Update(float deltaTime) override;
	void Render(float deltaTime) const override;

private:
	//Datamembers
	std::vector<SnakeGame*> TesterGames;
	const int m_AmountOfSnakes{1000};
	int* m_AmountOfSnakesToRender;

	//statistics
	float m_HighestRecordedFitness{0};
	float m_LastGenHighestFitness{0};
	float m_Generation{0};
	float m_HighestFitnessGen{ 0 };
	float m_HighestEverSize{0};
	float m_HighestSizeLastGen{0};

	//C++ make the class non-copyable
	App_Sandbox(const App_Sandbox&) = delete;
	App_Sandbox& operator=(const App_Sandbox&) = delete;
	float m_TickTime;
	float m_AccuTime;
};
#endif