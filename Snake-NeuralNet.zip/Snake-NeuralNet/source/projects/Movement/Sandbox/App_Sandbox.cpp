//Precompiled Header [ALWAYS ON TOP IN CPP]
#include "stdafx.h"
//#define humanTesting
//Includes
#include "App_Sandbox.h"
#include "SnakeGame/SnakeGame.h"


//Destructor
App_Sandbox::~App_Sandbox()
{
	delete m_AmountOfSnakesToRender;
	for (SnakeGame* games : TesterGames)
	{
		delete games;
	}
}

//Functions
void App_Sandbox::Start()
{
	//Initialization of your application. If you want access to the physics world you will need to store it yourself.
	m_AmountOfSnakesToRender = new int{ 1 };
	TesterGames.resize(m_AmountOfSnakes);
	int y = 1;
	int x = 1;
	for (int i = 0; i < m_AmountOfSnakes; ++i)
	{
		if (!(i % 40))
		{
			y += 200;
			x = 0;
		}
		TesterGames[i] = new SnakeGame(Vector2((x * 200), y));
		x++;
	}
	m_AccuTime = 0;
	m_TickTime = 0.2f;
}

void App_Sandbox::Update(float deltaTime)
{
	float amountAliveSnakes=0;
	//INPUT
	if (INPUTMANAGER->IsMouseButtonUp(Elite::InputMouseButton::eLeft))
	{
		auto const mouseData = INPUTMANAGER->GetMouseData(Elite::InputType::eMouseButton, Elite::InputMouseButton::eLeft);
		std::cout << mouseData.X << ' ' << mouseData.Y << '\n';
	}

	for (SnakeGame* game : TesterGames)
	{
#ifdef humanTesting
		game->HumanInputHandler();
#endif

		if (game->IsSnakeAlive())
		{
			amountAliveSnakes++;
		}
	}

#ifdef PLATFORM_WINDOWS
	//UI
	{
		//Setup
		int const menuWidth = 200;
		int const width = DEBUGRENDERER2D->GetActiveCamera()->GetWidth();
		int const height = DEBUGRENDERER2D->GetActiveCamera()->GetHeight();

		bool windowActive = true;
		ImGui::SetNextWindowPos(ImVec2((float)width - menuWidth - 10, 10));
		ImGui::SetNextWindowSize(ImVec2((float)menuWidth, (float)height - 20));
		ImGui::Begin("Gameplay Programming", &windowActive, ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoCollapse);
		ImGui::PushAllowKeyboardFocus(false);

		//Elements
		ImGui::Text("Basic info");
		ImGui::Indent();
		const char* test { };
		ImGui::Text("amount of snakes : %.1f ",static_cast<float>(m_AmountOfSnakes));
		//ImGui::SliderInt("Amount of snakes to render", m_AmountOfSnakesToRender,1,m_AmountOfSnakes);
		ImGui::Text("test");
		ImGui::Text("Scrollwheel: zoom cam.");
		ImGui::Unindent();

		ImGui::Spacing();
		ImGui::Separator();
		ImGui::Text("Options");
		ImGui::Indent();
		ImGui::Text("Amount of snakes to render");
		ImGui::SliderInt("", m_AmountOfSnakesToRender, 1, m_AmountOfSnakes);
		ImGui::Spacing();
		ImGui::Spacing();

		ImGui::Text("Stats");
		ImGui::Indent();
		ImGui::Text("Current gen %1.f",m_Generation);
		ImGui::Text("Highest fitness last gen:");
		ImGui::Text("%.1f", m_LastGenHighestFitness);
		ImGui::Text("highest fitness ever");
		ImGui::Text("%.1f",m_HighestRecordedFitness);
		ImGui::Text("Best generation");
		ImGui::Text("%.1f", m_HighestFitnessGen);
		ImGui::Text("%.1f are still alive",amountAliveSnakes);
		ImGui::Unindent();

		ImGui::Spacing();
		ImGui::Separator();
		ImGui::Spacing();
		ImGui::Spacing();

		ImGui::Text("Framework Performance stuff");
		ImGui::Indent();
		ImGui::Text("%.3f ms/frame", 1000.0f / ImGui::GetIO().Framerate);
		ImGui::Text("%.1f FPS", ImGui::GetIO().Framerate);
		ImGui::Unindent();

		//End
		ImGui::PopAllowKeyboardFocus();
		ImGui::End();
	}
#endif

	m_AccuTime += deltaTime;
	if (m_AccuTime > m_TickTime)
	{

		for (SnakeGame* game : TesterGames)
		{
			game->ActiveBrain();
			game->update();
		}
	
		m_AccuTime = 0;
	}

	if (amountAliveSnakes == 0)
	{
		m_LastGenHighestFitness = INT16_MIN;
		float secondHighest = INT16_MIN;

		std::vector<std::vector<std::vector<float>>> Highestweights;
		std::vector<std::vector<float>> Highestbiases;
		std::vector<std::vector<std::vector<float>>> Secondweights;
		std::vector<std::vector<float>> Secondbiases;

		for (SnakeGame* game : TesterGames)
		{
			if (m_LastGenHighestFitness < game->getSnakeFitness())
			{
				m_LastGenHighestFitness = game->getSnakeFitness();

				Highestweights = game->getWeights();
				Highestbiases = game->getBiases();
			}

			if (game->getSnakeFitness() > secondHighest and game->getSnakeFitness() < m_LastGenHighestFitness)
			{
				Secondweights = game->getWeights();
				Secondbiases = game->getBiases();
				secondHighest = game->getSnakeFitness();
			}

			game->resetGame();
		}

		if (m_LastGenHighestFitness > m_HighestRecordedFitness)
		{
			m_HighestRecordedFitness = m_LastGenHighestFitness;
			m_HighestFitnessGen = m_Generation;
		}
		m_Generation++;

		int i = 0;

		for (SnakeGame* game : TesterGames)
		{
			if (i <= 50)
			{
				
				game->SetWeightsAndBiases(Highestweights, Highestbiases);
				//game->mutateBrain(true, true, true);
			}
			else if (i <= 100 and i > 50)
			{
				//game->mutateBrain(true, false, false);
				game->SetWeightsAndBiases(Secondweights, Secondbiases);
			}
			else if(i <= 350 and i>100)
			{
				game->SetWeightsAndBiases(Highestweights, Highestbiases);
				game->mutateBrain(true, false,false);
			}
			else if (i <= 500 and i > 350)
			{
				game->SetWeightsAndBiases(Highestweights, Highestbiases);
				game->mutateBrain(true, true,false);
			}
			else if (i <= 650 and i > 500)
			{
				game->SetWeightsAndBiases(Highestweights, Highestbiases);
				game->mutateBrain(true, false,false);
			}
			else if (i <= 800 and i > 650)
			{
				game->SetWeightsAndBiases(Highestweights, Highestbiases);
				game->mutateBrain(true, true,false);
			}
			else if (i <= 850 and i > 800)
			{
				game->SetWeightsAndBiases(Highestweights, Highestbiases);
				game->mutateBrain(true, false,true);
			}
			else if (i <= 900 and i > 850)
			{
				game->SetWeightsAndBiases(Highestweights, Highestbiases);
				game->mutateBrain(true, true,true);
			}
			else
			{
				//game->SetWeightsAndBiases(Highestweights, Highestbiases);
				game->mutateBrain(true, true, true);
			}
			i++;
		}
		Highestbiases.clear();
		Highestweights.clear();
		Secondweights.clear();
		Secondbiases.clear();

	}

}

void App_Sandbox::Render(float deltaTime) const
{

	
	for (int i = 0; i < *m_AmountOfSnakesToRender; ++i)
	{
		TesterGames[i]->render();
	}
}